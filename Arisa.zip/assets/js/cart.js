/* Lightweight cart for static demo */

const CART_KEY = 'arisa_cart_v1';

function readCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
  catch (e) { return []; }
}
function writeCart(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
  refreshCount();
  renderCart();
}
function refreshCount() {
  const items = readCart();
  const count = items.reduce((n, i) => n + (i.qty || 1), 0);
  document.querySelectorAll('[data-cart-count]').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'grid' : 'none';
  });
}
function fmt(n) {
  return new Intl.NumberFormat('en-EU', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n);
}
function renderCart() {
  const body = document.querySelector('[data-cart-body]');
  const total = document.querySelector('[data-cart-total]');
  if (!body) return;
  const items = readCart();
  if (items.length === 0) {
    body.innerHTML = `<div class="cart-empty">
      <p class="lede">Your atelier basket is quietly waiting.</p>
      <a class="btn btn-ghost" href="shop.html">Begin browsing <span class="arrow"></span></a>
    </div>`;
    if (total) total.textContent = fmt(0);
    return;
  }
  body.innerHTML = items.map((i, idx) => `
    <div class="cart-item">
      <div class="imgph ${i.tone || ''}"><span class="label">${i.placeholder || 'doll portrait'}</span></div>
      <div>
        <div class="name">${i.name}</div>
        <div class="meta">${i.subtitle || 'One-of-one'}</div>
        <div class="row">
          <div class="price" style="font-family: var(--mono); font-size: 13px; letter-spacing:.08em;">${fmt(i.price)}</div>
          <button class="remove" data-remove="${idx}">Remove</button>
        </div>
      </div>
    </div>
  `).join('');
  if (total) total.textContent = fmt(items.reduce((s, i) => s + i.price * (i.qty || 1), 0));

  body.querySelectorAll('[data-remove]').forEach(btn => {
    btn.addEventListener('click', () => {
      const items = readCart();
      items.splice(Number(btn.dataset.remove), 1);
      writeCart(items);
      toast('Removed from basket');
    });
  });
}

function openCart() {
  document.querySelector('[data-cart-overlay]').classList.add('open');
  document.querySelector('[data-cart-drawer]').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  document.querySelector('[data-cart-overlay]').classList.remove('open');
  document.querySelector('[data-cart-drawer]').classList.remove('open');
  document.body.style.overflow = '';
}

function addToCart(product) {
  const items = readCart();
  // each reborn is one-of-one; do not stack quantities
  if (items.find(i => i.id === product.id)) {
    toast('Already reserved in basket');
    openCart();
    return;
  }
  items.push(product);
  writeCart(items);
  toast('Added — held for 30 minutes');
  openCart();
}

function toast(msg) {
  let t = document.querySelector('.toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 2200);
}

document.addEventListener('DOMContentLoaded', () => {
  refreshCount();
  renderCart();
  document.querySelectorAll('[data-open-cart]').forEach(b => b.addEventListener('click', openCart));
  document.querySelectorAll('[data-close-cart]').forEach(b => b.addEventListener('click', closeCart));
  document.querySelectorAll('[data-add-to-cart]').forEach(b => {
    b.addEventListener('click', () => {
      try {
        const data = JSON.parse(b.dataset.product);
        addToCart(data);
      } catch (e) { console.warn(e); }
    });
  });
});

window.ArisaCart = { open: openCart, close: closeCart, add: addToCart, read: readCart, write: writeCart };
