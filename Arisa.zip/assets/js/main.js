/* Arisa in WonderDolls — site interactions */

// ----- Mobile menu -----
(function () {
  const btn = document.querySelector('[data-menu-open]');
  const closeBtn = document.querySelector('[data-menu-close]');
  const menu = document.querySelector('.mobile-menu');
  if (!btn || !menu) return;
  btn.addEventListener('click', () => { menu.classList.add('open'); document.body.style.overflow = 'hidden'; });
  closeBtn && closeBtn.addEventListener('click', () => { menu.classList.remove('open'); document.body.style.overflow = ''; });
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { menu.classList.remove('open'); document.body.style.overflow = ''; }));
})();

// ----- Reveal on scroll -----
(function () {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  // Immediately reveal anything already in (or near) the initial viewport
  // — guarantees first paint is full even if IntersectionObserver is slow/blocked.
  const showInView = () => {
    const vh = window.innerHeight || document.documentElement.clientHeight;
    els.forEach(el => {
      if (el.classList.contains('in')) return;
      const r = el.getBoundingClientRect();
      if (r.top < vh * 0.95) el.classList.add('in');
    });
  };
  showInView();
  // Safety net: if IO never fires for some reason, reveal everything after 600ms.
  setTimeout(() => { els.forEach(el => el.classList.add('in')); }, 600);

  if (!('IntersectionObserver' in window)) {
    els.forEach(el => el.classList.add('in'));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (en.isIntersecting) {
        en.target.classList.add('in');
        io.unobserve(en.target);
      }
    });
  }, { rootMargin: '0px 0px -10% 0px', threshold: 0.05 });
  els.forEach(el => io.observe(el));
})();

// ----- Year stamp -----
document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
